<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>
<?php
$kode_event = $_GET['id'];
echo "<table border='0' cellpadding='0' cellspacing='0'>     
     	<form id='view_event' action='' method='get' >
		<input type='hidden' name='halaman' value='' /> ";
                                          
            $mysqlselect = "SELECT * FROM `event` WHERE `event`.`kode_event` = '$kode_event'";
			$hasil=mysql_query($mysqlselect) or die ("mysql_error");
			while($data=mysql_fetch_array($hasil)){						
			echo "
	<tr>  	
    	<td>
			<table border='0'>
				<tr>
					<td colspan='6'><a href='view_event.php?id=".$data['kode_event']."'><h3>$data[nama]</h3></a></td>
				</tr>
				<tr>
					<td colspan='6'>";  	
					$pembuat = showPenulis($data['kode_pembuat']);
					echo "
					</td>
				</tr>
				<tr>
					<td colspan='6'><small>Tanggal dibuat: ".$data['tanggal_dibuat'].". Penulis: ".$pembuat."</small></td>
				</tr>
				<tr>
					<td colspan='6'><img src='$data[gambar]' height='200' width='250' /></td>
				</tr>
				<tr>
					<td colspan='6'>Lokasi : ".$data['lokasi']."</td>
				</tr>				
				<tr>
					<td>Tanggal Mulai</td>
					<td>:</td>
					<td>".$data['tanggal_mulai']."</td>
					<td>Jam Mulai</td>
					<td>:</td>
					<td>".$data['jam_mulai']."</td>
				</tr>			
				<tr>
					<td>Tanggal Selesai</td>
					<td>:</td>
					<td>".$data['tanggal_selesai']."</td>
					<td>Jam Selesai</td>
					<td>:</td>
					<td>".$data['jam_selesai']."</td>
				</tr>			
				
				<tr>
					<td colspan='6'>Detail Beasiswa <br/><p> "
					.substr($data['deskripsi'],0,250)."</p>
					<a href='view_beasiswa.php?id=".$data['kode_event']."'>Baca selengkapnya...</a>
					</td>
				</tr>
								
				</table>
			</td>	 
		</tr>";
		}
echo "</table>";
?>

</body>
</html>