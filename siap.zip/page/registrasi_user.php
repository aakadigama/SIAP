<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registrasi</title>
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#status').change(function () {
            var value = $(this).val(); var toAppend = '';
            if (value == "mahasiswa") {
				toAppend = "NIM";	$("#tempat_nama").html(toAppend);
				toAppend = ":";	$("#tempat_titikdua").html(toAppend);
			    toAppend = "<input type='number' name='nim' required='required' >"; $("#tempat_form").html(toAppend); return;
            }
            if (value == "alumni") {
				toAppend = "Pekerjaan";	$("#tempat_nama").html(toAppend);
				toAppend = ":";	$("#tempat_titikdua").html(toAppend);
               	toAppend = "<input type='text' name='pekerjaan' required='required' >"; $("#tempat_form").html(toAppend); return;
			}
			if (value == "") {
				toAppend = "";	$("#tempat_nama").html(toAppend);
				toAppend = "";	$("#tempat_titikdua").html(toAppend);
			    toAppend = ""; $("#tempat_form").html(toAppend); return;
            }
        });

    });
     </script>
</head>

<body>

	<h2>Form Registrasi</h2>
<form name="registrasi_mahasiswa" action="" method="post" enctype="multipart/form-data">
	<table align="center" cellpadding="4" cellspacing="8">
    	<tr> 
      		<td><label for="name">Nama</label></td>
            <td>:</td>
            <td><input type="text" name="nama" placeholder="Nama Lengkap" required="required" /></td>
    	</tr>
        <tr> 
        	<td><label for="gambar">Gambar</label></td>
            <td>:</td>
            <td><input type='file' name='Filegambar' id='Filegambar' size='30' />  </td>
        </tr>         
    	<tr> 
        	<td><label for="program_studi">Program Studi</label></td>
            <td>:</td>
            <td><select name="program_studi" required="required">
            <option value="">---</option>
            <?php
            	$result = mysql_query("SELECT * FROM `prodi` WHERE kode_prodi != 0");
                while ($data = mysql_fetch_array($result)) {
                ?>
              		<option value="<?php echo $data['kode_prodi'] ?>"><?php echo $data['program_studi'] ?></option>
              	<?php
                }
            ?>
            </select></td>         
		</tr>
        <tr> 
        	<td><label for="phone">Nomor Handphone</label></td>
            <td>:</td>
            <td><input type="number" maxlength="12" name="phone" placeholder="081XXX" required="required" /></td>      
        </tr> 
    	<tr> 
        	<td><label for="email">Email</label></td>
            <td>:</td>
            <td><input type="email" name="email" placeholder="nama@email.com" required="required" /></td>          
        </tr>        
        
        <tr> 
        	<td valign="top"><label for="alamat">Alamat</label></td>
            <td valign="top">:</td>
            <td><input type="text" name="alamat" size="35" required="required" /></td>          
        </tr>
        <tr> 
        	<td><label for="tahun_masuk">Tahun Masuk</label></td>
            <td>:</td>
            <td><input type="number" size="4" name="tahun_masuk" required="required" /></td>              
        </tr>
        <tr> 
        	<td><label for="username">Username</label></td>
            <td>:</td>
            <td><input type="text" name="username" required="required" /></td>              
        </tr>
        <tr> 
        	<td><label for="password">Password</label></td>
            <td>:</td>
            <td><input type="password" name="password" required="required" /></td>              
        </tr>
        <tr> 
        	<td valign="top"><label for="status">Status</label></td>
            <td valign="top">:</td>
            <td>
           		<select id="status" name="status" required="required">
                	<option value="">---</option>
                    <option value="mahasiswa">Mahasiswa</option>
                    <option value="alumni" selected="selected">Alumni</option>                    
                </select>
               
            </td>
        </tr>      
        <tr>
        	<td><div id="tempat_nama"></div></td>
            <td><div id="tempat_titikdua"</td>
        	<td><div id="tempat_form"></div></td>
        </tr>
        </tr>        
    	<tr> 
        	<td colspan="3" align="center"><button class="submit" type="submit" name="submit">Kirim</button></td>
       </tr>
	</table>
    <?php
		if (isset($_POST['submit'])) {
			$nama = strip_tags(trim($_POST['nama']));
			$program_studi = strip_tags(trim($_POST['program_studi']));
			$phone = strip_tags(trim($_POST['phone']));
			$email = strip_tags(trim($_POST['email']));
			
			
			$alamat = strip_tags(trim($_POST['alamat']));
			
					
			$tahun_masuk = strip_tags(trim($_POST['tahun_masuk']));
			$username = strip_tags(trim($_POST['username']));
			$password = strip_tags(trim($_POST['password']));
			$status = strip_tags(trim($_POST['status']));
			
			if($status == "mahasiswa"){
				$nim = strip_tags(trim($_POST['nim']));				
				$namafolder="images/user/"; //folder tempat menyimpan file
				if (!empty($_FILES["Filegambar"]["tmp_name"]))
					{
						$jenis_gambar=$_FILES['Filegambar']['type'];
						if($jenis_gambar=="image/jpeg" || $jenis_gambar=="image/jpg" || $jenis_gambar=="image/gif" || $jenis_gambar=="image/x-png")
						{           
							$gambar = $namafolder . $nim . basename($_FILES['Filegambar']['name']);       
							if (move_uploaded_file($_FILES['Filegambar']['tmp_name'], $gambar)) {
								echo "Gambar berhasil dikirim ".$gambar;
								$insertmahasiswa = "INSERT INTO `infodkpm`.`user` (`kode_user`, `nama`, `gambar`, `prodi`, `nomor_handphone`, 
																	   `email`, `alamat`, `tahun_masuk`, `username`, `password`, 
																		`post`, `status_user`, `pekerjaan`)
															VALUES ('$nim', '$nama', '$gambar', '$program_studi', '$phone', 
																	'$email', '$alamat', '$tahun_masuk', '$username', MD5('$password'), 
																	'0', 'mahasiswa', '');";
								$query = mysql_query($insertmahasiswa) or die (mysql_error);
							}else {
								echo "Gambar gagal dikirim";
							}
						}else{
							echo "Jenis gambar yang anda kirim salah. Harus .jpg .gif .png";
						}
					}else{
						echo "Anda belum memilih gambar";
				}
			}else if ($status == "alumni"){
				$selectm = mysql_query("select max(kode_user) from user where kode_user LIKE 'ALM-%'");
				$datam = mysql_fetch_array($selectm);
				$explode = explode("-", $datam[0]);
				$numeric = $explode[1];
				$write = $numeric + 1;
				
				if (strlen($write) == 1) {
					$kode_user = "ALM-0000" . $write;
				}
				if (strlen($write) == 2) {
					$kode_user = "ALM-000" . $write;
				}
				if (strlen($write) == 3) {
					$kode_user = "ALM-00" . $write;
				}
				if (strlen($write) == 4) {
					$kode_user = "ALM-0" . $write;
				}
				if (strlen($write) == 5) {
					$kode_user = "ALM-" . $write;
				}
				$pekerjaan = strip_tags(trim($_POST['pekerjaan']));
				$namafolder="images/user/"; //folder tempat menyimpan file
				if (!empty($_FILES["Filegambar"]["tmp_name"]))
				{
					$jenis_gambar=$_FILES['Filegambar']['type'];
					if($jenis_gambar=="image/jpeg" || $jenis_gambar=="image/jpg" || $jenis_gambar=="image/gif" || $jenis_gambar=="image/x-png"){           
						$gambar = $namafolder . $kode_user . basename($_FILES['Filegambar']['name']);       
						if (move_uploaded_file($_FILES['Filegambar']['tmp_name'], $gambar)) {
							echo "Gambar berhasil dikirim ".$gambar;
							
							$insertalumni = "INSERT INTO `infodkpm`.`user` (`kode_user`, `nama`, `gambar`, `prodi`, `nomor_handphone`, `email`, `alamat`, `tahun_masuk`, `username`, `password`, `post`, `status_user`, `pekerjaan`) VALUES ('$kode_user', '$nama', '$gambar', '$program_studi', '$phone', '$email', '$alamat', '$tahun_masuk', '$username', '$password', '0', 'alumni', '$pekerjaan');";
							$query = mysql_query($insertalumni) or die (mysql_error);
							
						}else {
							echo "Gambar gagal dikirim";
						}
					}else{
						echo "Jenis gambar yang anda kirim salah. Harus .jpg .gif .png";
					}
				}else{
					echo "Anda belum memilih gambar";
				}
			}		
		}
	?>
</body>
</html>
