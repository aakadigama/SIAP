<?php
$kode_beasiswa = $_GET['id'];
$mysqlselect = "SELECT * FROM `beasiswa` WHERE `beasiswa`.`kode_beasiswa` = '$kode_beasiswa'";
			$hasil=mysql_query($mysqlselect) or die ("mysql_error");
			while($data=mysql_fetch_array($hasil)){	
			$pembuat = showPenulis($data['kode_pembuat']);
?>
			<!-- BEGIN BLOG -->
			<div class="row">
				<!-- BEGIN LEFT SIDEBAR -->            
				<div class="col-md-9 blog-item margin-bottom-40">
				
					<h2><a href=""><?php echo $data['nama']; ?></a></h2>
					
					<p><?php echo $data['deskripsi']; ?></p>
					<ul class="blog-info">
						<li><i class="fa fa-user"></i><?php echo $pembuat; ?></li>
						<li><i class="fa fa-calendar"></i><?php echo $data['tanggal_dibuat'];?></li>						
					</ul>					
					
					<hr>
					<div class="post-comment">
						<h3>Leave a Comment</h3>
						<form role="form">
							<div class="form-group">
								<label>Name</label>
								<input type="text" class="form-control">
							</div>

							<div class="form-group">
								<label>Email <span class="color-red">*</span></label>
								<input type="text" class="form-control">
							</div>

							<div class="form-group">
								<label>Message</label>
								<textarea class="form-control" rows="8"></textarea>
							</div>
							<p><button class="btn btn-default theme-btn" type="submit">Post a Comment</button></p>
						</form>
					</div>
				</div>
				<!-- END LEFT SIDEBAR -->

				         
			</div>
			<!-- END BEGIN BLOG -->
			<?php 
			}
			?>
