<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>
<?php
$kode_beasiswa = $_GET['id'];
echo "<table border='0' cellpadding='0' cellspacing='0'>     
     	<form id='view_beasiswa' action='' method='get' >
		<input type='hidden' name='halaman' value='' /> ";
                                          
            $mysqlselect = "SELECT * FROM `beasiswa` WHERE `beasiswa`.`kode_beasiswa` = '$kode_beasiswa'";
			$hasil=mysql_query($mysqlselect) or die ("mysql_error");
			while($data=mysql_fetch_array($hasil)){						
			echo "
	<tr>  	
    	<td>
			<table border='0'>
				<tr>
					<td colspan='2'><h3>$data[nama]</h3></td>					
				<tr>
					<td colspan='2'>"; 					 	
					$pembuat = showPenulis($data['kode_pembuat']);
			
				echo "
					</td>
				</tr>
				<tr>
					<td><small>Tanggal dibuat: ".$data['tanggal_dibuat'].". Penulis: ".$pembuat."</small></td>
				</tr>
				<tr>
					<td><img src='$data[gambar]' height='200' width='250' /></td>
				</tr>
				<tr>
					<td>Detail Beasiswa</td>
				</tr>
				<tr>
					<td><p> ".$data['deskripsi']."</p></td>			
				</tr>
				</table>
			</td>	 
		</tr>";
		}
		echo "</table>";
?>

</body>
</html>